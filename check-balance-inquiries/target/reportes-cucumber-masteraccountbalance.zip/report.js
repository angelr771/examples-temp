$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("200_MasterAccountBalance.feature");
formatter.feature({
  "line": 1,
  "name": "It must get master account balance",
  "description": "       and response (HTTP Code) 200 OK.",
  "id": "it-must-get-master-account-balance",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "This test validates that when placing valid data, respond with a status of 200",
  "description": "",
  "id": "it-must-get-master-account-balance;this-test-validates-that-when-placing-valid-data,-respond-with-a-status-of-200",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 7,
    "value": ""
  }
});
formatter.step({
  "line": 9,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 10
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 11
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 12
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 13
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 14
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 15
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 16
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 17
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 18
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 20,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"51440796\",\r\n    \"branchCode\": \"347\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 29,
  "name": "the service should response Http code \u003c200\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 30,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 31,
    "value": "{\r\n  \"masterAccount\": {\r\n    \"availableBalanceAmount\": 366957.07,\r\n    \"currentBalanceAmount\": 366957.07,\r\n    \"interestAmount\": 192.0,\r\n    \"lastActivityDate\": \"180924\",\r\n    \"pendingAuthorizationAmount\": 0.0,\r\n    \"totalDepositAmount\": 0.0,\r\n    \"totalWithdrawalAmount\": 0.0\r\n  }\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 1572612980,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 424932,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 155518182,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 787147,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "200",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 1259436,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 1009853211,
  "status": "passed"
});
formatter.after({
  "duration": 148044,
  "status": "passed"
});
formatter.uri("400_ValidateRequest.feature");
formatter.feature({
  "line": 1,
  "name": "It must indicate that the server could not understand the request due to invalid syntax",
  "description": "       and response (HTTP Code) 400 Bad Request.",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "This test validates that when placing invalid data in dataCenterLocation (in this case set \"spaces\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-datacenterlocation-(in-this-case-set-\"spaces\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 7,
    "value": ""
  }
});
formatter.step({
  "line": 9,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 10
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 11
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 12
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 13
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 14
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 15
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 16
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 17
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 18
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 19
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 20
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 22,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"51440796\",\r\n    \"branchCode\": \"347\"\r\n  },\r\n  \"dataCenterLocation\": \" \"\r\n}"
  }
});
formatter.step({
  "line": 31,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 33,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"dataCenterLocation, No puede contener letras, caracteres especiales ni espacios en blanco, solo puede ir 4 o 10. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 26978044,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 233371,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 17616321,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 711633,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 441997,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 91071912,
  "status": "passed"
});
formatter.after({
  "duration": 130551,
  "status": "passed"
});
formatter.scenario({
  "line": 43,
  "name": "This test validates that when placing invalid data in dataCenterLocation (in this case set \"\"letters\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-datacenterlocation-(in-this-case-set-\"\"letters\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 44,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 45,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 46,
    "value": ""
  }
});
formatter.step({
  "line": 48,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 49
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 50
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 51
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 52
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 53
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 54
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 55
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 56
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 57
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 58
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 59
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 60,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 61,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"51440796\",\r\n    \"branchCode\": \"347\"\r\n  },\r\n  \"dataCenterLocation\": \"Wx\"\r\n}"
  }
});
formatter.step({
  "line": 70,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 71,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 72,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"dataCenterLocation, No puede contener letras, caracteres especiales ni espacios en blanco, solo puede ir 4 o 10. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 43783753,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 235931,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 30368112,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 902340,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 345150,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 83644140,
  "status": "passed"
});
formatter.after({
  "duration": 160842,
  "status": "passed"
});
formatter.scenario({
  "line": 82,
  "name": "This test validates that when placing invalid data in dataCenterLocation (in this case set \"\"characters\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-datacenterlocation-(in-this-case-set-\"\"characters\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 83,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 84,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 85,
    "value": ""
  }
});
formatter.step({
  "line": 87,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 88
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 89
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 90
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 91
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 92
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 93
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 94
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 95
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 96
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 97
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 98
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 99,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 100,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"51440796\",\r\n    \"branchCode\": \"347\"\r\n  },\r\n  \"dataCenterLocation\": \"#$\"\r\n}"
  }
});
formatter.step({
  "line": 109,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 110,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 111,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"dataCenterLocation, No puede contener letras, caracteres especiales ni espacios en blanco, solo puede ir 4 o 10. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 22490237,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 224412,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 11956538,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 523059,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 500020,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 74537972,
  "status": "passed"
});
formatter.after({
  "duration": 58877,
  "status": "passed"
});
formatter.scenario({
  "line": 121,
  "name": "This test validates that when placing invalid data in accountNumber (in this case set \"\"spaces\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-accountnumber-(in-this-case-set-\"\"spaces\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 122,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 123,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 124,
    "value": ""
  }
});
formatter.step({
  "line": 126,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 127
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 128
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 129
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 130
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 131
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 132
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 133
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 134
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 135
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 136
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 137
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 138,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 139,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"56  34\",\r\n    \"branchCode\": \"347\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 148,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 149,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 150,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.accountNumber, No puede contener letras, caracteres especiales ni espacios en blanco, acepta  de 3 hasta 12 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 27911103,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 322965,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 18662438,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 690300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 312299,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 77644752,
  "status": "passed"
});
formatter.after({
  "duration": 46503,
  "status": "passed"
});
formatter.scenario({
  "line": 160,
  "name": "This test validates that when placing invalid data in accountNumber (in this case set \"\"letters\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-accountnumber-(in-this-case-set-\"\"letters\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 161,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 162,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 163,
    "value": ""
  }
});
formatter.step({
  "line": 165,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 166
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 167
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 168
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 169
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 170
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 171
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 172
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 173
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 174
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 175
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 176
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 177,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 178,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"ABCDE\",\r\n    \"branchCode\": \"347\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 187,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 188,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 189,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.accountNumber, No puede contener letras, caracteres especiales ni espacios en blanco, acepta  de 3 hasta 12 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 26250200,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 211186,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 15129873,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 693714,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 390374,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 87430554,
  "status": "passed"
});
formatter.after({
  "duration": 66129,
  "status": "passed"
});
formatter.scenario({
  "line": 199,
  "name": "This test validates that when placing invalid data in accountNumber (in this case set \"\"characters\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-accountnumber-(in-this-case-set-\"\"characters\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 200,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 201,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 202,
    "value": ""
  }
});
formatter.step({
  "line": 204,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 205
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 206
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 207
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 208
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 209
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 210
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 211
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 212
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 213
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 214
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 215
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 216,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 217,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"$%$\u0026\",\r\n    \"branchCode\": \"347\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 226,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 227,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 228,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.accountNumber, No puede contener letras, caracteres especiales ni espacios en blanco, acepta  de 3 hasta 12 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 19256745,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 155296,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 8595908,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 921965,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 234225,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 63073776,
  "status": "passed"
});
formatter.after({
  "duration": 46931,
  "status": "passed"
});
formatter.scenario({
  "line": 238,
  "name": "This test validates that when placing invalid data in accountNumber (in this case set \"\"less that 3 numbers\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-accountnumber-(in-this-case-set-\"\"less-that-3-numbers\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 239,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 240,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 241,
    "value": ""
  }
});
formatter.step({
  "line": 243,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 244
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 245
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 246
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 247
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 248
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 249
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 250
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 251
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 252
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 253
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 254
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 255,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 256,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"11\",\r\n    \"branchCode\": \"347\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 265,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 266,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 267,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.accountNumber, No puede contener letras, caracteres especiales ni espacios en blanco, acepta  de 3 hasta 12 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 14333766,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 157429,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 6763496,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 500873,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 184307,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 66952770,
  "status": "passed"
});
formatter.after({
  "duration": 43944,
  "status": "passed"
});
formatter.scenario({
  "line": 277,
  "name": "This test validates that when placing invalid data in accountNumber (in this case set \"\"more that 12 numbers\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-accountnumber-(in-this-case-set-\"\"more-that-12-numbers\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 278,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 279,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 280,
    "value": ""
  }
});
formatter.step({
  "line": 282,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 283
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 284
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 285
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 286
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 287
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 288
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 289
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 290
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 291
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 292
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 293
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 294,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 295,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"000123456789012\",\r\n    \"branchCode\": \"347\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 304,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 305,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 306,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.accountNumber, No puede contener letras, caracteres especiales ni espacios en blanco, acepta  de 3 hasta 12 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 18133833,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 176201,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 10184283,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 565723,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 341311,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 61151344,
  "status": "passed"
});
formatter.after({
  "duration": 46504,
  "status": "passed"
});
formatter.scenario({
  "line": 316,
  "name": "This test validates that when placing invalid data in accountNumber (in this case set \"\"NULL\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-accountnumber-(in-this-case-set-\"\"null\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 317,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 318,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 319,
    "value": ""
  }
});
formatter.step({
  "line": 321,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 322
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 323
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 324
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 325
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 326
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 327
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 328
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 329
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 330
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 331
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 332
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 333,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 334,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"\",\r\n    \"branchCode\": \"347\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 343,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 344,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 345,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.accountNumber, No puede contener letras, caracteres especiales ni espacios en blanco, acepta  de 3 hasta 12 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 15600882,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 147190,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 8873223,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 1906220,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 224412,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 61455963,
  "status": "passed"
});
formatter.after({
  "duration": 43944,
  "status": "passed"
});
formatter.scenario({
  "line": 355,
  "name": "This test validates that when placing invalid data in branchCode (in this case set \"\"NULL\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-branchcode-(in-this-case-set-\"\"null\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 356,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 357,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 358,
    "value": ""
  }
});
formatter.step({
  "line": 360,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 361
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 362
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 363
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 364
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 365
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 366
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 367
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 368
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 369
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 370
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 371
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 372,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 373,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"51440796\",\r\n    \"branchCode\": \"\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 382,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 383,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 384,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.branchCode, No puede contener letras, caracteres especiales ni espacios en blanco, acepta hasta 4 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 27438387,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 244891,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 63583181,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 541404,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 276461,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 68551810,
  "status": "passed"
});
formatter.after({
  "duration": 36264,
  "status": "passed"
});
formatter.scenario({
  "line": 394,
  "name": "This test validates that when placing invalid data in branchCode (in this case set \"\"letters\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-branchcode-(in-this-case-set-\"\"letters\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 395,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 396,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 397,
    "value": ""
  }
});
formatter.step({
  "line": 399,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 400
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 401
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 402
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 403
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 404
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 405
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 406
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 407
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 408
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 409
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 410
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 411,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 412,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"51440796\",\r\n    \"branchCode\": \"ab\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 421,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 422,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 423,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.branchCode, No puede contener letras, caracteres especiales ni espacios en blanco, acepta hasta 4 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 14579083,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 382268,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 12375496,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 411706,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 210332,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 63274721,
  "status": "passed"
});
formatter.after({
  "duration": 38397,
  "status": "passed"
});
formatter.scenario({
  "line": 433,
  "name": "This test validates that when placing invalid data in branchCode (in this case set \"\"spaces\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-branchcode-(in-this-case-set-\"\"spaces\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 434,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 435,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 436,
    "value": ""
  }
});
formatter.step({
  "line": 438,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 439
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 440
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 441
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 442
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 443
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 444
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 445
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 446
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 447
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 448
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 449
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 450,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 451,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"51440796\",\r\n    \"branchCode\": \"   \"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 460,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 461,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 462,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.branchCode, No puede contener letras, caracteres especiales ni espacios en blanco, acepta hasta 4 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 14253131,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 131831,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 8155617,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 494047,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 185161,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 66721533,
  "status": "passed"
});
formatter.after({
  "duration": 35411,
  "status": "passed"
});
formatter.scenario({
  "line": 472,
  "name": "This test validates that when placing invalid data in branchCode (in this case set \"\"characters\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-branchcode-(in-this-case-set-\"\"characters\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 473,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 474,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 475,
    "value": ""
  }
});
formatter.step({
  "line": 477,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 478
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 479
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 480
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 481
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 482
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 483
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 484
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 485
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 486
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 487
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 488
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 489,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 490,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"51440796\",\r\n    \"branchCode\": \"$#\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 499,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 500,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 501,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.branchCode, No puede contener letras, caracteres especiales ni espacios en blanco, acepta hasta 4 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 14116180,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 136098,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 5586401,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 373308,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 189854,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 57509559,
  "status": "passed"
});
formatter.after({
  "duration": 40530,
  "status": "passed"
});
formatter.scenario({
  "line": 511,
  "name": "This test validates that when placing invalid data in branchCode (in this case set  less that  3 numbers) it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-branchcode-(in-this-case-set--less-that--3-numbers)-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 512,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 513,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 514,
    "value": ""
  }
});
formatter.step({
  "line": 516,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 517
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 518
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 519
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 520
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 521
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 522
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 523
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 524
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 525
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 526
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 527
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 528,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 529,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"51440796\",\r\n    \"branchCode\": \"0\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 538,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 539,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 540,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.branchCode, No puede contener letras, caracteres especiales ni espacios en blanco, acepta hasta 4 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 11432199,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 123725,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 5675995,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 287981,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 167243,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 61570302,
  "status": "passed"
});
formatter.after({
  "duration": 36691,
  "status": "passed"
});
formatter.scenario({
  "line": 550,
  "name": "This test validates that when placing invalid data in branchCode (in this case set  more that  4 numbers) it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-branchcode-(in-this-case-set--more-that--4-numbers)-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 551,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 552,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 553,
    "value": ""
  }
});
formatter.step({
  "line": 555,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 556
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 557
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 558
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 559
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 560
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 561
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 562
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 563
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 564
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 565
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 566
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 567,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 568,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"51440796\",\r\n    \"branchCode\": \"000000\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 577,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 578,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 579,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account.branchCode, No puede contener letras, caracteres especiales ni espacios en blanco, acepta hasta 4 posiciones. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 17970004,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 1933098,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 7823266,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 1325565,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 4622625,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 59332158,
  "status": "passed"
});
formatter.after({
  "duration": 699687,
  "status": "passed"
});
formatter.scenario({
  "line": 589,
  "name": "This test validates that when placing invalid data in account (in this case set \"\"NULL\"\") it respond with 400 status",
  "description": "",
  "id": "it-must-indicate-that-the-server-could-not-understand-the-request-due-to-invalid-syntax;this-test-validates-that-when-placing-invalid-data-in-account-(in-this-case-set-\"\"null\"\")-it-respond-with-400-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 590,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 591,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 592,
    "value": ""
  }
});
formatter.step({
  "line": 594,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 595
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 596
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 597
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 598
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 599
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 600
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 601
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 602
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 603
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 604
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 605
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 606,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 607,
    "value": "{\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 612,
  "name": "the service should response Http code \u003c400\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 613,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 614,
    "value": "{\r\n  \"type\": \"invalid\",\r\n  \"code\": \"400\",\r\n  \"details\": \"MethodArgumentNotValidException\",\r\n  \"location\": \"request\",\r\n  \"moreInfo\": \"account, No puede ser null. \"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 27954619,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 166815,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 12446318,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 486368,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "400",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 246170,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 59515185,
  "status": "passed"
});
formatter.after({
  "duration": 43517,
  "status": "passed"
});
formatter.uri("404_ExecuteWithNotFound.feature");
formatter.feature({
  "line": 1,
  "name": "It must indicate that the system not found information with the data provided",
  "description": "       and response (HTTP Code) 404 Bad Request.",
  "id": "it-must-indicate-that-the-system-not-found-information-with-the-data-provided",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "This test validates that when branchId does not correspond to the accountNumber, and the dataCenterLocation is correct, it respond with 404 status",
  "description": "",
  "id": "it-must-indicate-that-the-system-not-found-information-with-the-data-provided;this-test-validates-that-when-branchid-does-not-correspond-to-the-accountnumber,-and-the-datacenterlocation-is-correct,-it-respond-with-404-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 7,
    "value": ""
  }
});
formatter.step({
  "line": 9,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 10
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 11
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 12
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 13
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 14
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 15
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 16
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 17
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 18
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 19
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 20
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 22,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"7734235\",\r\n    \"branchCode\": \"0870\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 31,
  "name": "the service should response Http code \u003c404\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 32,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 33,
    "value": "{\r\n  \"type\": \"error\",\r\n  \"code\": \"404\",\r\n  \"details\": \"Not Found Exception\",\r\n  \"location\": \"Unisys comunication\",\r\n  \"moreInfo\": \"ERROR : NO EXISTE CONTRATO EN LA BASE DE DATOS\"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 16898715,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 94714,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 5449878,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 427491,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "404",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 171935,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 160110090,
  "status": "passed"
});
formatter.after({
  "duration": 15359,
  "status": "passed"
});
formatter.scenario({
  "line": 43,
  "name": "This test validates that when accountNumber does not correspond to the branchId, and the dataCenterLocation is correct, it respond with 404 status",
  "description": "",
  "id": "it-must-indicate-that-the-system-not-found-information-with-the-data-provided;this-test-validates-that-when-accountnumber-does-not-correspond-to-the-branchid,-and-the-datacenterlocation-is-correct,-it-respond-with-404-status",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 44,
  "name": "the service with url \"POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance\"",
  "keyword": "Given "
});
formatter.step({
  "line": 45,
  "name": "the simulated response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 46,
    "value": ""
  }
});
formatter.step({
  "line": 48,
  "name": "the service is executed with headers",
  "rows": [
    {
      "cells": [
        "header",
        "value"
      ],
      "line": 49
    },
    {
      "cells": [
        "Authorization",
        "TOKENEXAMPLE"
      ],
      "line": 50
    },
    {
      "cells": [
        "Accept-Language",
        "MX"
      ],
      "line": 51
    },
    {
      "cells": [
        "Accept",
        "application/json"
      ],
      "line": 52
    },
    {
      "cells": [
        "uuid",
        "DU0908002345318"
      ],
      "line": 53
    },
    {
      "cells": [
        "Content-Type",
        "application/json"
      ],
      "line": 54
    },
    {
      "cells": [
        "countryCode",
        "MX"
      ],
      "line": 55
    },
    {
      "cells": [
        "sid",
        "12"
      ],
      "line": 56
    },
    {
      "cells": [
        "businesscode",
        "1"
      ],
      "line": 57
    },
    {
      "cells": [
        "ChannelId",
        "1521"
      ],
      "line": 58
    },
    {
      "cells": [
        "client_id",
        "SG05070"
      ],
      "line": 59
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 60,
  "name": "the body request",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 61,
    "value": "{\r\n  \"account\": {\r\n    \"accountNumber\": \"9999795\",\r\n    \"branchCode\": \"0870\"\r\n  },\r\n  \"dataCenterLocation\": \"10\"\r\n}"
  }
});
formatter.step({
  "line": 70,
  "name": "the service should response Http code \u003c404\u003e",
  "keyword": "Then "
});
formatter.step({
  "line": 71,
  "name": "the body response",
  "keyword": "And ",
  "doc_string": {
    "content_type": "",
    "line": 72,
    "value": "{\r\n  \"type\": \"error\",\r\n  \"code\": \"404\",\r\n  \"details\": \"Not Found Exception\",\r\n  \"location\": \"Unisys comunication\",\r\n  \"moreInfo\": \"ERROR : NO EXISTE CONTRATO EN LA BASE DE DATOS\"\r\n}"
  }
});
formatter.match({
  "arguments": [
    {
      "val": "POST http://acmt-api-a-master-account-balance-mx-sit1.cfapps-gt1-dev.lac.nsroot.net/api/v1/accounts/master/balance",
      "offset": 22
    }
  ],
  "location": "ServiceExecutor.the_service_with(String)"
});
formatter.result({
  "duration": 11780762,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_simulated_response(String)"
});
formatter.result({
  "duration": 114766,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_service_is_executed_with_headers(Header\u003e)"
});
formatter.result({
  "duration": 3904167,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_request(String)"
});
formatter.result({
  "duration": 259396,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "404",
      "offset": 39
    }
  ],
  "location": "ServiceExecutor.the_service_should_response_Http_code(int)"
});
formatter.result({
  "duration": 205639,
  "status": "passed"
});
formatter.match({
  "location": "ServiceExecutor.the_body_response(String)"
});
formatter.result({
  "duration": 130847824,
  "status": "passed"
});
formatter.after({
  "duration": 22185,
  "status": "passed"
});
});